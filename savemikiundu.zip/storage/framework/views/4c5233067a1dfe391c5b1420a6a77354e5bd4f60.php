<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SAVE MIKIUNDU | <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('images/icon/apple-touch-icon.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/icon/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/icon/favicon-16x16.png')); ?>">
        <link rel="manifest" href="<?php echo e(asset('images/icon/site.webmanifest')); ?>">
        <link rel="mask-icon" href="<?php echo e(asset('images/icon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
        <link rel="shortcut icon" href="<?php echo e(asset('images/icon/favicon.ico')); ?>">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="msapplication-config" content="<?php echo e(asset('images/icon/browserconfig.xml')); ?>">
        <meta name="theme-color" content="#ffffff">

        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/bootstrap.min.css')); ?>">

        <!-- FontAwesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/font-awesome.min.css')); ?>">

        <!-- ElegantFonts CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/elegant-fonts.css')); ?>">

        <!-- themify-icons CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/themify-icons.css')); ?>">

        <!-- Swiper CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/swiper.min.css')); ?>">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/front_end/style.css')); ?>">
    </head>
    <body>
        <?php echo $__env->make('layouts.frontlayout.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.frontlayout.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/jquery.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/jquery.collapsible.min.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/swiper.min.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/jquery.countdown.min.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/circle-progress.min.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/jquery.countTo.min.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/jquery.barfiller.js')); ?>'></script>
        <script type='text/javascript' src='<?php echo e(asset('js/front_end/custom.js')); ?>'></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\savemikiundu\resources\views/layouts/frontlayout/front_design.blade.php ENDPATH**/ ?>